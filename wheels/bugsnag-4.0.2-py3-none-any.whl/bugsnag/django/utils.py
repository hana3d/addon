class MiddlewareMixin:
    def __init__(self, get_response=None):
        super(MiddlewareMixin, self).__init__()
